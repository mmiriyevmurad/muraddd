﻿using System;

class Program
{
    static void Main()
    {
         1)Console.Write("Adınızı daxil edin: ");
        string ad = Console.ReadLine();

        Console.Write("Yaşınızı daxil edin: ");
        int yas = Convert.ToInt32(Console.ReadLine());

        Console.Write("Boyunuzu daxil edin: ");
        double boy = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Salam, menim adım " + ad + "dır. Men " + yas + " yasım var, boyum " + boy + " m-dir."); 

/* 2)const double usdSabit = 1.7;
 const double eurSabit = 1.82;

 Console.Write("Manat məbləğini daxil edin: ");
 string yazi = Console.ReadLine();

 double azn;
 bool duzgundurmu = double.TryParse(yazi, out azn);

 if (duzgundurmu == true)
 {
     Console.WriteLine("Dollar: " + (azn / usdSabit));
     Console.WriteLine("Avro: " + (azn / eurSabit));
 }
 else
 {
     Console.WriteLine("Xəta: Yalnız rəqəm yazın!");
 } */

/* 3) Console.Write("1-ci qiyməti daxil edin: ");
 int q1 = Convert.ToInt32(Console.ReadLine());

 Console.Write("2-ci qiyməti daxil edin: ");
 int q2 = Convert.ToInt32(Console.ReadLine());

 Console.Write("3-cü qiyməti daxil edin: ");
 int q3 = Convert.ToInt32(Console.ReadLine());

 Console.Write("4-cü qiyməti daxil edin: ");
 int q4 = Convert.ToInt32(Console.ReadLine());

 Console.Write("5-ci qiyməti daxil edin: ");
 int q5 = Convert.ToInt32(Console.ReadLine());

 // Orta balı tapmaq üçün toplayıb 5-ə bölürük
 double orta = (q1 + q2 + q3 + q4 + q5) / 5.0;
 Console.WriteLine("Orta balınız: " + orta);

 if (orta < 51)
 {
     Console.WriteLine("Kəsildiniz");
 }
 else if (orta <= 90)
 {
     Console.WriteLine("Orta nəticə");
 }
 else
 {
     Console.WriteLine("Əla nəticə");
 } */
/* const double faiz = 0.12;

        Console.Write("Pulu daxil edin: ");
        double pul = Convert.ToDouble(Console.ReadLine());

        Console.Write("Neçə il qalacaq: ");
        int il = Convert.ToInt32(Console.ReadLine());

        double netice = pul * (1 + faiz * il);
        
        Console.WriteLine("Yekun məbləğ: " + netice); */


/* 11)Console.Write("Məsafəni daxil edin: ");
double km = Convert.ToDouble(Console.ReadLine());

Console.Write("Yanacağı daxil edin: ");
double litr = Convert.ToDouble(Console.ReadLine());

if (km < 0 || litr < 0)
{
    Console.WriteLine("Daxil edilən məlumat yanlışdır!");
}
else
{
    double serfiyyat = (litr / km) * 100;
    Console.WriteLine("100 km üçün sərfiyyat: " + serfiyyat);
}  */

}
}
